import streamlit as st
import numpy as np
import math
from ultralytics import YOLO
import cv2
import datetime


def main():
    st.title("Live Hexapod Feed")
    model = YOLO('yolov8n.pt')
   
    classNames=[
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat", "traffic light",
    "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow",
    "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
    "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove", "skateboard", "surfboard",
    "tennis racket", "bottle", "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich",
    "orange", "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch", "potted plant", "bed",
    "dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard", "cell phone", "microwave", "oven",
    "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush"
]
    # Open the video stream
    hand_url=r"C:\Users\Gaming\Desktop\tenzin\hand.jpeg"
    cap = cv2.VideoCapture("url")
    frame_placeholder = st.empty()
    if not cap.isOpened():
        st.error("Error: Failed to open video stream.")
        return
    i=0
    while cap.isOpened():

        ret, frame = cap.read()

        if i % 10 != 0:
            i=i+1
            continue
        i=i+1

        if not ret:
            st.error("Error: Couldn't read frame.")
            break

        # Perform object detection on the frame
        results = model(frame, stream=True)

        for r in results:
            boxes = r.boxes
            
            for box in boxes:

                x1, y1, x2, y2 = box.xyxy[0]
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                
                confidence = math.ceil((box.conf[0] * 100))
                cls = int(box.cls[0])
                if classNames[cls]=='person':
                    formatteddatetime=datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(frame, classNames[cls], [x1, y1], cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                    cv2.imwrite(f"D:/detected/{formatteddatetime}.jpg", frame)


        i=i+1
        frame_placeholder.image(frame,channels="BGR")
        # Exit on 'q' key press
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release resources
    cap.release()

if __name__ == "__main__":
    main()